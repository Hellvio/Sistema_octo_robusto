// script.js

document.addEventListener('DOMContentLoaded', () => {
    const hamburger = document.getElementById('hamburger-menu');
    const navMenu = document.getElementById('nav-menu');
    const body = document.body; // Para controlar o overflow do body

    // Função para fechar o menu
    const closeMenu = () => {
        if (navMenu.classList.contains('active')) {
            navMenu.classList.remove('active');
            hamburger.classList.remove('active');
            body.classList.remove('no-scroll');
            console.log("Menu fechado.");
        }
    };

    // Verifica se os elementos essenciais existem antes de adicionar event listeners
    if (hamburger && navMenu) {
        // Event listener para o clique no ícone do hambúrguer
        hamburger.addEventListener('click', () => {
            navMenu.classList.toggle('active');
            hamburger.classList.toggle('active');
            body.classList.toggle('no-scroll'); // Ativa/desativa o scroll do body
            console.log("Hambúrguer clicado. Menu ativo:", navMenu.classList.contains('active'));
        });

        // Event listener para cliques nos links do menu (para fechar o menu após a navegação)
        navMenu.querySelectorAll('ul li a').forEach(link => {
            link.addEventListener('click', () => {
                closeMenu();
            });
        });

        // Event listener para fechar o menu ao clicar fora dele
        document.addEventListener('click', (e) => {
            // Se o menu está ativo E o clique não foi no menu NEM no hambúrguer
            if (navMenu.classList.contains('active') && !navMenu.contains(e.target) && !hamburger.contains(e.target)) {
                closeMenu();
            }
        });

        // Fecha o menu se a janela for redimensionada para desktop
        window.addEventListener('resize', () => {
            if (window.innerWidth >= 768) { // 768px é o breakpoint do CSS para mobile/desktop
                closeMenu();
            }
        });

    } else {
        console.error("Erro: Elementos 'hamburger-menu' ou 'nav-menu' não encontrados. Verifique seus IDs no HTML.");
    }
});